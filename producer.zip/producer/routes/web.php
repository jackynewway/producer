<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/collectdata', function () {
    return view('collectdata');
});
Route::get('/tochart', function () {
    return view('tochart');
});
Route::get('/jqplot', function () {
    return view('jqplot');
});
//Route::resource('producer', 'ProducerController');

Route::post('producer/channel', 'ProducerController@store');
Route::get('producer/channel', 'ProducerController@channellist');
Route::get('producer/channel/{id}', 'ProducerController@channel');
Route::patch('producer/channel/{id}', 'ProducerController@update');
Route::delete('producer/channel/{id}', 'ProducerController@destroy');
Route::post('producer/channel/{id}/item', 'ProducerController@additem');
Route::get('producer/channel/{id}/{from}/{to}', 'ProducerController@itemslistfromto');
