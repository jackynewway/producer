<!DOCTYPE html>
<html>
<head>
    <title>Data Point labels</title>
    <link href="{!! asset('css/jquery.jqplot.min.css') !!}" rel="stylesheet" type="text/css">
	
    <!--[if lt IE 9]><script language="javascript" type="text/javascript" src="../excanvas.js"></script><![endif]-->
    <script type="text/javascript" src="{!! asset('js/jquery.min.js') !!}"></script>
     <script type="text/javascript" src="{!! asset('js/jquery.jqplot.min.js') !!}"></script>
    <script type="text/javascript" src="{!! asset('js/jqplot.dateAxisRenderer.js') !!}"></script>
</head>
<body>
   
    <div class="colmask leftmenu">
      <div class="colleft">
        <div class="col1" id="example-content">


<div id="chart1" style="height:500px; width:800px;"></div>

<script type="text/javascript">
var channel_1=[];
var channel_2=[];
var channel_3=[];
var plot1=null;
$(document).ready(function(){
	
		setInterval(function(){
			var d = new Date();
			var n = d.getTime();
			var from_time=n-100000;
			var to_time=n;		
			
			$.ajax({
				url:'/producer/channel/1/'+from_time+'/'+to_time,
				type:"GET",
				headers:{"Content-Type":"application/json"},
				dataType:'json',
				contentType: "application/json; charset=utf-8",
				beforeSend: function (event, files, index, xhr, handler, callBack) {
					 $.ajax({
						 async: false,
						 url: '' // add path
					 });
				},
				success:function(data){					
					channel_1=[];
					for(var i=0;i<data.length;i++){
						channel_1.push([data[i].created_at,data[i].item_value]);
					}				
					
					$("#chart1").html('');
					plot1 = $.jqplot('chart1', [channel_1,channel_2,channel_3], {
					  title: 'Chart with Point Labels', 
					  seriesDefaults: { 
						showMarker:false,
						pointLabels: { show:false } 
					  },
					  axes:{
						xaxis:{ 
						renderer:$.jqplot.DateAxisRenderer,
						tickOptions:{formatString:'%H:%M'},
						tickInterval:'5 second'
						},
						yaxis: {
							min:0,
							tickInterval : 10,
							max:100							
						}
					  },
					  seriesColors: ["#bc4427",  "#2026e4", "#5e8c41", "#739c9b", "#3483b3"],
					  series: [
						  { label: 'channel_1'},
						  { label: 'channel_2' },
						  { label: 'channel_3' }
						],
					  legend:{show:true}
					  
					});					
				}				
			});			
		},1000);
		
		setInterval(function(){
			var d = new Date();
			var n = d.getTime();
			var from_time=n-100000;
			var to_time=n;		
			
			$.ajax({
				url:'/producer/channel/2/'+from_time+'/'+to_time,
				type:"GET",
				headers:{"Content-Type":"application/json"},
				dataType:'json',
				contentType: "application/json; charset=utf-8",
				beforeSend: function (event, files, index, xhr, handler, callBack) {
					 $.ajax({
						 async: false,
						 url: '' // add path
					 });
				},
				success:function(data){					
					channel_2=[];
					for(var i=0;i<data.length;i++){
						channel_2.push([data[i].created_at,data[i].item_value]);
					}				
				}				
			});			
		},1500);
		
		setInterval(function(){
			var d = new Date();
			var n = d.getTime();
			var from_time=n-100000;
			var to_time=n;		
			
			$.ajax({
				url:'/producer/channel/3/'+from_time+'/'+to_time,
				type:"GET",
				headers:{"Content-Type":"application/json"},
				dataType:'json',
				contentType: "application/json; charset=utf-8",
				beforeSend: function (event, files, index, xhr, handler, callBack) {
					 $.ajax({
						 async: false,
						 url: '' // add path
					 });
				},
				success:function(data){					
					channel_3=[];
					for(var i=0;i<data.length;i++){
						channel_3.push([data[i].created_at,data[i].item_value]);
					}				
				}				
			});			
		},2000);  
  
});
</script>

     </div>
         
  </div>
</div>
</body>
</html>