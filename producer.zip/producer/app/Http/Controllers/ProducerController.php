<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use DB;

class ProducerController extends Controller
{
    
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $datas=json_decode($request->getcontent(),true);
		
		$id=DB::table('channel')->insertGetId(['name'=>$datas['channel name']]);
		
		return json_encode(array('channel id'=>$id,'channel name'=>$datas['channel name']));
    }
	
	/**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function channellist()
    {
		$channels=DB::table('channel')->get();
		
        return json_encode($channels);
    }
	
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function channel($id)
    {
		$id=(int)$id;
        $channel=DB::table('channel')->where(['id'=>$id])->get();
		
        return json_encode($channel);
		
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
		$datas=json_decode($request->getcontent(),true);
		
		DB::table('channel')->where('id',$id)->update(['name'=>$datas['channel name']]);
		$channel=DB::table('channel')->where(['id'=>$id])->get();
		
        return json_encode($channel);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		$channel=DB::table('channel')->where(['id'=>$id])->get();
        DB::table('channel')->where('id',$id)->delete();
		return json_encode($channel);
    }
	
	/**
     * Add item
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
	public function additem(Request $request,$id)
    {
        $datas=json_decode($request->input('data'),true);
		
				
		$item_id=DB::table('channel_items')
		->insertGetId(['channel_id'=>$id,'item_name'=>$datas['name'],'item_value'=>$datas['value']]);
		if($item_id){
			$item=DB::table('channel_items')->where(['item_id'=>$item_id])->get();
			$return=array('item_id'=>$item[0]->item_id,'name'=>$item[0]->item_name,'value'=>$item[0]->item_value,'created time'=>$item[0]->created_at);
			return json_encode($return);
		}else{
			return json_encode(array('status'=>'add item error'));
		}
				
    }
	
	/**
     * list item from to
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
	public function itemslistfromto($id,$from,$to)
    {
		
		$to_time=date("Y-m-d H:i:s",substr($to,0,10));
		
		$from_time=date("Y-m-d H:i:s",substr($from,0,10));
		        
		$items=DB::table('channel_items')
		->where('channel_id',$id)
		->where('created_at','>=',$from_time)
		->where('created_at','<=',$to_time)
		->get();
		
		return json_encode($items);	
				
    }
		
}
