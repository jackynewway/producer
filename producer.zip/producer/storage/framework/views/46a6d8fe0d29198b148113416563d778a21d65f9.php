<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
		<script type="text/javascript" src="<?php echo asset('js/jquery.min.js'); ?>"></script>
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
		<script>
		$(document).ready(function(){
			setInterval(function(){
				var name=Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 8);
				var value=Math.floor((Math.random() * 100) + 1);
				var data=JSON.stringify({'name':name,'value':value});
				
				$.post('/producer/channel/1/item',{data:data},function(data){
					console.info(data);
				});
				
			},1000);
			
			setInterval(function(){
				var name=Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 8);
				var value=Math.floor((Math.random() * 100) + 1);
				var data=JSON.stringify({'name':name,'value':value});
				
				$.post('/producer/channel/2/item',{data:data},function(data){
					console.info(data);
				});
				
			},1500);
			
			setInterval(function(){
				var name=Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 8);
				var value=Math.floor((Math.random() * 100) + 1);
				var data=JSON.stringify({'name':name,'value':value});
				
				$.post('/producer/channel/3/item',{data:data},function(data){
					console.info(data);
				});
				
			},2000);
			
		});
		</script>
    </head>
    <body>
        <div class="flex-center position-ref full-height">            

            <div class="content">
                <div class="title m-b-md">
                    Collect Data ..........
                </div>
               
            </div>
        </div>
    </body>
</html>
